import sys
import os
print("\n♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠")
print("\033[1m♠  Bienvenido a Super la Bendicion  ♠\033[0m")
print("♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠")

def crearArea():
    # Ruta de la carpeta "áreas"
    ruta_areas = "./areas"
    print("\n*****************************Pantalla Activa*****************************")
    print("SI decea regresar al menu anterior digite volver")
    # Pedir al usuario el nombre de la nueva carpeta
    nombre_nueva_carpeta = input("Ingrese el nombre de la nueva area: ")
    if nombre_nueva_carpeta == "volver":
        return
    # Crear la ruta completa de la nueva carpeta
    # Se une la ruta de la carpeta (./areas/) con el nombre que el usuario ingresa.
    ruta_nueva_carpeta = os.path.join(ruta_areas, nombre_nueva_carpeta)

    # Comprobar si la carpeta ya existe
    if os.path.exists(ruta_nueva_carpeta):
        # Mensaje en caso de que la nueva carpeta ya exista.
        print(f"La area '{nombre_nueva_carpeta}' ya existe en '{ruta_areas}'.")
    else:
        # Crear la nueva carpeta
        # La funcion os.mkdir que nos permite crear carpetas en el directorio actual.
        os.mkdir(ruta_nueva_carpeta)
        print(f"La area '{nombre_nueva_carpeta}' se ha creado exitosamente en '{ruta_areas}'.")

def crearCategoria():
    # Ruta de la carpeta "áreas"
    ruta_areas = "./areas/"

    while True:
        print("\n*****************************Pantalla Activa*****************************")
        print("SI decea regresar al menu anterior digite volver")   
        print("\nAreas Disponibles: \n")
        # Se utiliza un bucle for para iterar sobre los elementos dentro de la carpeta especificada por ruta_areas.
        for carpeta in os.listdir(ruta_areas):
            # Sentencia que evite mostrar por pantalla la carpeta (.DS_Store)
            # La carpeta .DS_Store es una carpeta que moestraba mi MAC aunque no hubiera ninguna carpeta con ese nombre.
            if carpeta != ".DS_Store":
                # Se muestran los elementos que se encuentrar dentro de la ruta identificada como ./areas/
                print(carpeta) 
        # Pedir al usuario el nombre de la carpeta a verificar
        nombre_carpeta = input("\nIngrese el nombre de la area donde ira la nueva categoria: ")
        if nombre_carpeta == "volver":
            return
        # Crear la ruta completa de la carpeta a verificar
        # Se unifican el nombre ingresado por el usuario con la ruta establecida previamente (./areaa/)
        rutacategoria = os.path.join(ruta_areas, nombre_carpeta)

        # Verificar si la carpeta existe
        if os.path.exists(rutacategoria):
            break
        else:
            # Mensaje en caso de que el usuario quiera acceder a un area que no existe.
            print(f"La area '{nombre_carpeta}' no existe: ")

    
    # Pedir al usuario el nombre de la nueva categoria
    nombre_nueva_categoria = input("Ingrese el nombre de la nueva categoria: ")

    # Crear la ruta completa de la nueva carpeta
    # Se une el nombre de la nueva carpea con la ruta de la categoria a la que pertenece.
    ruta_nueva_carpeta = os.path.join(rutacategoria, nombre_nueva_categoria)

    # Comprobar si la carpeta ya existe
    if os.path.exists(ruta_nueva_carpeta):
        # Mensaje en caso de que la categoria ya exista.
        print(f"La categoria '{nombre_nueva_categoria}' ya existe en el area '{nombre_carpeta}'.")
    else:
        # Crear la nueva carpeta con la funcion os.mkdir con la ruta establecida en: ruta_nueva_carpeta
        os.mkdir(ruta_nueva_carpeta)
        print(f"La categoria '{nombre_nueva_categoria}' se ha creado exitosamente en el area '{nombre_carpeta}'.")
        # Crear la ruta completa del archivo
        nombre_archivo = "productos.txt"
        # Se le añade un archivo txt a la nueva carpeta creada.
        # Se la ruta de la nueva carpeta con el nombre establecido (productos.txt)
        ruta_archivo = os.path.join(ruta_nueva_carpeta, nombre_archivo)
        # Crear el archivo de texto
        with open(ruta_archivo, 'w') as archivo:
            archivo.write("\n")

def verProductos():
    while True:
        # Definir la ruta de la carpeta principal
        ruta_areas = "./areas/"
        while True:
            # Mostrar las carpetas disponibles en la carpeta principal
            print("\n*****************************Pantalla Activa*****************************")
            print("\nÁreas dispoiblels en este programa.")
            print("Si decea salir dijite volver\n")
            for carpeta in os.listdir(ruta_areas):
                if carpeta != ".DS_Store":
                    print(carpeta)

            # Pedir al usuario que seleccione una de las carpetas
            carpeta_seleccionada = input("\nIngrese el nombre del área a la que desee ingresar -> ")
            
            if carpeta_seleccionada == "volver":
                print("A regresado al menu aneterio")
                break
            # Definir la ruta de la carpeta seleccionada
            ruta_carpeta_seleccionada = ruta_areas + carpeta_seleccionada + "/"
            if os.path.exists(ruta_carpeta_seleccionada):
                break
            else:
                print("El area ingresada no existe, por favor seleccione un area")
        if carpeta_seleccionada == "volver":
            break
            
        
        while True:
            # Mostrar las carpetas disponibles dentro de la carpeta seleccionada
            print("\n*****************************Pantalla Activa*****************************")
            print("\nCategorias disponibles dentro del area:\n")
            for carpeta in os.listdir(ruta_carpeta_seleccionada):
                if carpeta != ".DS_Store":
                    print(carpeta)

            # Pedir al usuario que seleccione una de las carpetas dentro de la carpeta seleccionada
            carpeta_dentro_seleccionada = input("\nIngrese el nombre de la categoria a la que desee ingresar -> ")

            # Definir la ruta de la carpeta seleccionada dentro de la carpeta principal
            ruta_carpeta_dentro_seleccionada = ruta_carpeta_seleccionada + carpeta_dentro_seleccionada + "/"
            if os.path.exists(ruta_carpeta_dentro_seleccionada):
                break
            else:
                print("La categoria ingresada no existe, por favor seleccione una categoria existente ")
            

        # asignacion de la ruta del archivo donde contiene los productos 
        archivo_seleccionado = "productos.txt"
        
        ruta_archivo_seleccionado = ruta_carpeta_dentro_seleccionada + archivo_seleccionado
        with open(ruta_archivo_seleccionado, "r") as archivo:
            contenido = archivo.read()
            print("\n*****************************Pantalla Activa*****************************")
            print("\nLos porductos disponibles en esta categoria son:\n")
            print(contenido)

        while True:
            desi = input("\nDesea ingresar a otra area -> ").lower()
            if desi == "si" or desi == "no":
                break
            else:
                print("\nIngrese una opcion valida")
        if desi == "no":
            break
        
def añadirProducto():
    ruta_areas = "./areas/"

    while True:
        # Definir la ruta de la carpeta principal
        ruta_areas = "./areas/"
        while True:
            # Mostrar las carpetas disponibles en la carpeta principal
            print("\n*****************************Pantalla Activa*****************************")
            print("\nSI decea regresar al menu anterior digite volver")  
            print("Áreas de este programa en las que puede agregar productos:\n")
            for carpeta in os.listdir(ruta_areas):
                if carpeta != ".DS_Store":
                    print(carpeta)

            # Pedir al usuario que seleccione una de las carpetas
            carpeta_seleccionada = input("\nIngrese el nombre del área a la que desee ingresar -> ").lower()
            if carpeta_seleccionada == "volver":
                break
            # Definir la ruta de la carpeta seleccionada
            ruta_carpeta_seleccionada = ruta_areas + carpeta_seleccionada + "/"
            if os.path.exists(ruta_carpeta_seleccionada):
                break
            else:
                print("El area ingresada no existe, por favor seleccione un area")
        if carpeta_seleccionada == "volver":
            break
        
        while True:    
            while True:
                # Mostrar las carpetas disponibles dentro de la carpeta seleccionada
                print("\n*****************************Pantalla Activa*****************************")
                print("\nCategorias disponibles dentro del area:\n")
                for carpeta in os.listdir(ruta_carpeta_seleccionada):
                    if carpeta != ".DS_Store":
                        print(carpeta)
                # Pedir al usuario que seleccione una de las carpetas dentro de la carpeta seleccionada
                carpeta_dentro_seleccionada = input("\nIngrese el nombre de la categoria a la que desea ingresar el nuevo producto -> ")
                # Definir la ruta de la carpeta seleccionada dentro de la carpeta principal
                ruta_carpeta_dentro_seleccionada = ruta_carpeta_seleccionada + carpeta_dentro_seleccionada + "/"
                # Pedir al usuario que seleccione un archivo dentro de la carpeta seleccionada dentro de la carpeta principal
                archivo_seleccionado = "productos.txt"
                if os.path.exists(ruta_carpeta_dentro_seleccionada):
                    break
                else:
                    print("La categoria no existe, por favor ingrese a una categoria existente")

            while True:
                ruta_archivo_seleccionado = ruta_carpeta_dentro_seleccionada + archivo_seleccionado
                with open(ruta_archivo_seleccionado, "r") as archivo:
                    contenido = archivo.read()
                    print("\n*****************************Pantalla Activa*****************************")
                    print("\nLos porductos disponibles en esta categoria son:\n")
                    print(contenido)
                    
                    producto = input("\nIngrese el producto a agregar -> ").lower()
                    proveedor = input("\nIngrese el proveedor del producto -> ")
                    fechaDeEntrada = input("\nFecha de entrada -> ")
                    fechaDeVenci = input("\nFecha de vencimiento -> ")
                    detalles = input("\nDetalles del producto -> ")
                    precio = float(input("\nPrecio del producto -> "))
                    cantidad = int(input("\nIngrese la cantidad de productos disponibles -> "))
                    with open(ruta_archivo_seleccionado, "a") as archivo:
                        nuevo_producto = f"{producto}, {proveedor}, {fechaDeEntrada}, {fechaDeVenci}, {detalles}, {precio}, {cantidad}\n"
                        archivo.write(nuevo_producto)
                    
                    while True:
                        x = input("\nQuiere agregar otro producto -> ").lower()
                        if x == "si" or x == "no":
                            break
                        else:
                            print("\nIngrese una opción valida.")
                
                if x == "no":
                    break

            if x == "no":
                break

        if x == "no":
            break

def venderProducto():
    vender = []
    precios2 = []
    unidades2 = []
    total = []
    total2 = []
    otro1 = "no"
    otro2 = "no"
    while True:
        # Definir la ruta de la carpeta principal
        ruta_areas = "./areas/"
        while True:
            # Mostrar las carpetas disponibles en la carpeta principal
            print("\n*****************************Pantalla Activa*****************************")
            print("\nÁreas dispoiblels en este programa.")
            print("Si decea salir dijite volver\n")
            for carpeta in os.listdir(ruta_areas):
                if carpeta != ".DS_Store":
                    print(carpeta)

            # Pedir al usuario que seleccione una de las carpetas
            carpeta_seleccionada = input("\nIngrese el nombre del área a la que desee ingresar -> ")
            
            if carpeta_seleccionada == "volver":
                print("A regresado al menu aneterio")
                break
            # Definir la ruta de la carpeta seleccionada
            ruta_carpeta_seleccionada = ruta_areas + carpeta_seleccionada + "/"
            if os.path.exists(ruta_carpeta_seleccionada):
                break
            else:
                print("El area ingresada no existe, por favor seleccione un area")
        if carpeta_seleccionada == "volver":
            break
            
        while True:
            while True:
                # Mostrar las carpetas disponibles dentro de la carpeta seleccionada
                print("\n*****************************Pantalla Activa*****************************")
                print("\nCategorias disponibles dentro del area:\n")
                for carpeta in os.listdir(ruta_carpeta_seleccionada):
                    if carpeta != ".DS_Store":
                        print(carpeta)

                # Pedir al usuario que seleccione una de las carpetas dentro de la carpeta seleccionada
                carpeta_dentro_seleccionada = input("\nIngrese el nombre de la categoria a la que desee ingresar -> ")

                # Definir la ruta de la carpeta seleccionada dentro de la carpeta principal
                ruta_carpeta_dentro_seleccionada = ruta_carpeta_seleccionada + carpeta_dentro_seleccionada + "/"
                if os.path.exists(ruta_carpeta_dentro_seleccionada):
                    break
                else:
                    print("La categoria ingresada no existe, por favor seleccione una categoria existente ")
                

            # asignacion de la ruta del archivo donde contiene los productos 
            archivo_seleccionado = "productos.txt"
            
            ruta_archivo_seleccionado = ruta_carpeta_dentro_seleccionada + archivo_seleccionado
            while True:
                with open(ruta_archivo_seleccionado, "r") as archivo:
                    print("\n*****************************Pantalla Activa*****************************")
                    print("Productos disponibles\n")
                    for linea in archivo: 
                        contenido = linea.strip().split(", ")
                        print(contenido[0])

                producto = input("\nIngrese el nombre de uno de los productos disponibles --->").lower()
                with open(ruta_archivo_seleccionado, "r") as archivo:
                    for linea in archivo:
                        datos = linea.strip().split(", ")
                        # Verificar el producto
                        if datos[0] == producto:
                            print(f"Nombre: {datos[0]} \nPrecio: ${datos[5]} \nCatidad Disponible: {datos[6]}")
                            producto = datos[0]
                            proveedor = datos[1]
                            fechaDeEntrada = datos[2]
                            fechaDeVenci = datos[3]
                            detalles = datos[4]
                            preci = datos[5]
                            cantidad = datos[6]
                                    
                    while True:
                        unidad = int(input("Ingrese las unidades que se venderán -> "))
                        dato = int(cantidad)
                        if unidad > dato:
                            print("\nNo hay sufiecientes unidades para realizar la venta, por favor eliga una cantidad menor.\n")
                        else:
                            dato -= unidad
                            break
                    # Leer el archivo originalmente y guardar los datos en una lista
                    with open(ruta_archivo_seleccionado, "r") as archivo:
                        lineas = archivo.readlines()

                    # Abrir el archivo en modo de escritura para sobrescribirlo
                    with open(ruta_archivo_seleccionado, "w") as archivo:
                        for linea in lineas:
                            datos = linea.strip().split(", ")

                            # Verificar si el Id coincide y omitir la línea en caso afirmativo
                            if datos[0] == producto:
                                continue
                            archivo.write(linea)
                            
                    with open(ruta_archivo_seleccionado, "a") as archivo:
                        nuevo_producto = f"{producto}, {proveedor}, {fechaDeEntrada}, {fechaDeVenci}, {detalles}, {preci}, {dato}\n"
                        archivo.write(nuevo_producto)   
                            
                    vender.append(producto)
                    precio = float(preci)
                    precios2.append(str(precio))
                    unidades2.append(str(unidad))
                    pagar = round(precio*unidad,2)
                    total.append(pagar)
                    total2.append(str(pagar))
                    print("\n*****************************Pantalla Activa*****************************")
                    while True:
                        otro = input("\n¿Desea vender otro producto? ").lower()
                        if otro == "si" or otro == "no":
                            break
                        else:
                            print("\n*****************************Pantalla Activa*****************************")
                            print("\nOpción invalida, vuelva a intentarlo.")
                    if otro == "no":
                        break
                if otro == "no":
                    break

                while True:
                    print("\n*****************************Pantalla Activa*****************************")
                    otro2 = input(f"\n¿El producto a vender pertenece a la misma area ({carpeta_seleccionada})? ").lower()
                    if otro2 == "si" or otro2 == "no": 
                        break
                    else:
                        print("\n*****************************Pantalla Activa*****************************")
                        print("\nOpcion invalida, vuelva a intentarlo.")
                if otro2 == "no":
                    break
            
                while True:
                    print("\n*****************************Pantalla Activa*****************************")
                    otro1 = input(f"\n¿El producto a vender pertenece a la misma categoria ({carpeta_dentro_seleccionada})? ").lower()
                    if otro1 == "si" or otro1 == "no": 
                        break
                    else:
                        print("\n*****************************Pantalla Activa*****************************")
                        print("\nOpcion invalida, vuelva a intentarlo.")
                
                if otro1 == "no" or otro == "no":
                    break
            if otro2 == "no":
                break
            if otro == "no":
                break
        if otro == "no":
            break

    sumaTotal = sum(total)
    # contador del numero de ventas que se realizaron.
    veces = len(vender)

    print('''
    ****************************************************************
    *     Unidades     ** Producto y precio  **    Precio total    *''')
    # Bucle que recorra cada venta realizada (i = vender, j = precios2, k = unidades2, l = total2)
    for indice, (i,j,k,l) in enumerate(zip(vender,precios2,unidades2,total2)):
        if indice < veces:
            print(f'''****************************************************************
    *        {k}        **  {i}  ${j}   **      ${l}        *''')

    print("****************************************************************")
    print(f"*     Total a pagar:                             ${sumaTotal}        *")
    print("****************************************************************")

    print("\n*****************************Pantalla Activa*****************************")
    print("\nVenta realizada con exito, la factura se encuentra arriba.")
    
# Función para crear el nuevo usuario del Jefe
def modificar_usuario_Jefe():
    
    ruta_archivo = "usuarios/DatosJefe.txt"

    with open(ruta_archivo, "w") as archivo:
        archivo.truncate(0)
    
    print("A continuacion se le pediran los datos nuevos del usuario Jefe")
    # Pedir al usuario los datos del nuevo usuario
    id_usuario = input("Ingrese el nuevo Id: ")
    nombre = input("Ingrese el nombre del usuario: ")
    contrasena = input("Ingrese su contraseña")
    edad = input("Ingrese la edad del usuario: ")
    nivel = "Jefe"

    # Abrir el archivo en modo de escritura, con el flag "a" para agregar al final
    with open("usuarios/DatosJefe.txt", "a") as archivo:
        nuevo_usuario = f"{id_usuario}, {nombre}, {contrasena}, {edad}, {nivel}\n"
        archivo.write(nuevo_usuario)
    print("El usuario se ha modificado exitosamente.")

# Función para crear el nuevo usuario del Jefe
def crear_usuario_Admin():
    print("\n*****************************Pantalla Activa*****************************")
    # Pedir al usuario los datos del nuevo usuario
    id_usuario = input("Ingrese el nuevo Id: ")
    nombre = input("Ingrese el nombre del usuario: ")
    contrasena = input("Ingrese su contraseña")
    edad = input("Ingrese la edad del usuario: ")
    nivel = "Administrador"

    # Abrir el archivo en modo de escritura, con el flag "a" para agregar al final
    with open("usuarios/DatosAdmin.txt", "a") as archivo:
        nuevo_usuario = f"{id_usuario}, {nombre}, {contrasena}, {edad}, {nivel}\n"
        archivo.write(nuevo_usuario)

    print("Usuario agregado exitosamente.")

# Función para eliminar Usuario del Jefe
def eliminar_usuario_Admin():
    while True:
        print("\n*****************************Pantalla Activa*****************************")
        print("\nUsuarios dispoiblels para eliminar:")
        print("Si decea regresar al menu anterior dijite volver\n")
        with open("usuarios/DatosAdmin.txt", "r") as archivo:
            contenido = archivo.read()
            print(contenido)
         
        id_usuario = input("Ingrese el Id del usuario a eliminar: ")
        if id_usuario == "volver":
            print("A regresado al menu anterior")
            break   
        # Leer el archivo originalmente y guardar los datos en una lista
        with open("usuarios/DatosAdmin.txt", "r") as archivo:
            lineas = archivo.readlines()

        # Abrir el archivo en modo de escritura para sobrescribirlo
        with open("usuarios/DatosAdmin.txt", "w") as archivo:
            usuario_eliminado = False
            for linea in lineas:
                datos = linea.strip().split(", ")

                # Verificar si el Id coincide y omitir la línea en caso afirmativo
                if datos[0] == id_usuario:
                    usuario_eliminado = True
                    continue
                archivo.write(linea)

            if usuario_eliminado:
                print("Usuario eliminado exitosamente.")
            else:
                print("No se encontró ningún usuario con el Id especificado.")

# Función para crear el nuevo usuario del Vendedor
def crear_usuario_Ven():
    print("\n*****************************Pantalla Activa*****************************")
    # Pedir al usuario los datos del nuevo usuario
    id_usuario = input("Ingrese el nuevo Id: ")
    nombre = input("Ingrese el nombre del usuario: ")
    contrasena = input("Ingrese su contraseña")
    edad = input("Ingrese la edad del usuario: ")
    nivel = "Vendedor"

    # Abrir el archivo en modo de escritura, con el flag "a" para agregar al final
    with open("usuarios/DatosVen.txt", "a") as archivo:
        nuevo_usuario = f"{id_usuario}, {nombre}, {contrasena}, {edad}, {nivel}\n"
        archivo.write(nuevo_usuario)

    print("Usuario agregado exitosamente.")

# Función para eliminar Usuario del Vendedor
def eliminar_usuario_Ven():
    while True:
        print("\n*****************************Pantalla Activa*****************************")
        print("\nUsuarios dispoiblels para eliminar:")
        print("Si decea regresar al menu anterior dijite volver\n")
        with open("usuarios/DatosVen.txt", "r") as archivo:
            contenido = archivo.read()
            print(contenido)
         
        id_usuario = input("Ingrese el Id del usuario a eliminar: ")
        if id_usuario == "volver":
            print("A regresado al menu anterior")
            break   
        # Leer el archivo originalmente y guardar los datos en una lista
        with open("usuarios/DatosVen.txt", "r") as archivo:
            lineas = archivo.readlines()

        # Abrir el archivo en modo de escritura para sobrescribirlo
        with open("usuarios/DatosVen.txt", "w") as archivo:
            usuario_eliminado = False
            for linea in lineas:
                datos = linea.strip().split(", ")

                # Verificar si el Id coincide y omitir la línea en caso afirmativo
                if datos[0] == id_usuario:
                    usuario_eliminado = True
                    continue

                archivo.write(linea)

            if usuario_eliminado:
                print("Usuario eliminado exitosamente.")
            else:
                print("No se encontró ningún usuario con el Id especificado.")
#Inicio de sesion de usuarios          
while True:
    print("\n*****************************Pantalla Activa*****************************")
    print("\033[1m\nPor favor inicie seción.\033[0m")
    print("Si decea cerrar el programa escriba salir en el ID\n")
    id = input("Por favor ingrese su ID institucional: ")
    if id == "salir":
        print("\n*****************************Pantalla Desactivada*****************************")
        print("A salido del programa")
        sys.exit()
    contrasena = input("Por favor ingrese su contraseña: ")
    
    with open("usuarios/DatosJefe.txt", "r") as archivo:
        for linea in archivo:
            datos = linea.strip().split(", ")
            if len(datos) >= 3 and datos[0] == id and datos[2] == contrasena:
                coincidencia = "Jefe"
                break
            else:
                coincidencia = "no"

    with open("usuarios/DatosAdmin.txt", "r") as archivo:
        for linea in archivo:
            datos = linea.strip().split(", ")
            if len(datos) >= 3 and datos[0] == id and datos[2] == contrasena:
                coincidencia = "Admin"
                break

    with open("usuarios/DatosVen.txt", "r") as archivo:
        for linea in archivo:
            datos = linea.strip().split(", ")
            if len(datos) >= 3 and datos[0] == id and datos[2] == contrasena:
                coincidencia = "Vendedor"
                break
    
    if coincidencia == "Jefe":
        while True:
            print("Sesión iniciada exitosamente.")
            print("\n*****************************Pantalla Activa*****************************")
            print("\nJefe bienvenido al programa, que decea realizar:")
            print("""\n1. Añadir Area, Categoria o producto \n2. Modificar Usuario \n3. Cambiar de cuenta \n4. Salir""") 
            opcion = int(input("\nIngrese una opcion -> "))
            while opcion == 1:
                print("\n*****************************Pantalla Activa*****************************")
                print("\n1. Añadir area \n2. Añadir categoria. \n3. Añadir producto \n4. Volver")
                tipo = int(input("\nQué nuevo apartado desea ingresar ---> "))
                if tipo == 1:
                    crearArea()
                elif tipo == 2:
                    crearCategoria()
                elif tipo == 3:
                    añadirProducto()
                elif tipo == 4:
                    print("\n*****************************Pantalla Activa*****************************")
                    print("\nA regresado al menu anterior")
                    break
                else:
                    print("Opción invalida.")
                    
            while opcion == 2:
                print("\n*****************************Pantalla Activa*****************************")
                print("1. Añadir un usuario \n2. Eliminar Usuario \n3. Modificar el usuario de Jefe \n4. Volver")
                opcion1 = int(input("\nElija una de las opciones del menu anterior: "))
                
                while opcion1 == 1:
                    print("\n*****************************Pantalla Activa*****************************")
                    print("\n1. Administrador \n2. Vendedor \n3. Volver")
                    clase = int(input("\nQue clase de usuario decea añadir ---> "))
                    if clase == 1:
                        crear_usuario_Admin()
                    elif clase == 2:
                        crear_usuario_Ven()
                    elif clase == 3:
                        print("\n*****************************Pantalla Activa*****************************")
                        print("\nA regresado al menu anterior")
                        break
                    else:
                        print("Opcion no valida")
                while opcion1 == 2:
                    print("\n*****************************Pantalla Activa*****************************")
                    print("\n1. Administrador \n2. Vendedor \n3. Volver")
                    clase = int(input("\nQue clase de usuario decea eliminar ---> "))
                    if clase == 1:
                        eliminar_usuario_Admin()
                    elif clase == 2:
                        eliminar_usuario_Ven()
                    elif clase == 3:
                        print("\n*****************************Pantalla Activa*****************************")
                        print("\nA regresado al menu anterior")
                        break
                    else:
                        print("Opcion no valida") 
                if opcion1 == 3:   
                    print("\n*****************************Pantalla Activa*****************************")
                    print("A decidido modificar el usuario de jefe \nA contunuacion se eliminaran los datos actuales y se solicitaran los nuevos datos")
                    modificar_usuario_Jefe()
                    print("\n*****************************Pantalla Activa*****************************")
                    print("Usuario de Jefe Modificado Correctamente")
                elif opcion1 == 4:
                    print("\n*****************************Pantalla Activa*****************************")
                    print("\nA regresado al menu anterior")
                    break
                else:
                    print("Opcion no valida")
                    
            if opcion == 3:
                print("\n*****************************Pantalla Activa*****************************")
                print("\nA regresado al menu anterior")
                break
            elif opcion == 4:
                print("\n*****************************Pantalla Desactivada*****************************")
                print("\nJefe a cerrado el programa, pase feliz tarde.\n")
                sys.exit()  

    elif coincidencia == "Admin":
        while True:
            print("Sesión iniciada exitosamente.")
            print("\n*****************************Pantalla Activa*****************************")
            print("\nAdministrador bienvenido al programa, que decea realizar:")
            print("\n1. Añadir Area, Categoria o producto \n2. Ver la lista de prodcutos \n3. Cambiar de cuenta \n4. Salir")
            opcion = int(input("\nIngrese una opcion -> "))
            while opcion == 1:
                print("\n*****************************Pantalla Activa*****************************")
                print("\n1. Añadir area \n2. Añadir categoria. \n3. Añadir producto \n4. Volver")
                tipo = int(input("\nQué nuevo apartado desea ingresar ---> "))
                if tipo == 1:
                    crearArea()
                elif tipo == 2:
                    crearCategoria()
                elif tipo == 3:
                    añadirProducto()
                elif tipo == 4:
                    print("\n*****************************Pantalla Activa*****************************")
                    print("\nA regresado al menu anterior")
                    break    
                else:
                    print("\nOpción invalida.")
            if opcion == 2:
                verProductos()
            elif opcion == 3:
                print("\n*****************************Pantalla Activa*****************************")
                print("\nA regresado al menu anterior")
                break
            elif opcion == 4:
                print("\n*****************************Pantalla Activa*****************************")
                print("\nAdministrador a cerrado el programa, pase feliz tarde.\n")
                sys.exit()  
            else:
                print("Opcion no valida")
                
    elif coincidencia == "Vendedor":
        while True:
            print("Sesión iniciada exitosamente.")
            print("\n*****************************Pantalla Activa*****************************")
            print("\nVendedor bienvenido al programa, que decea realizar:")
            print("""\n1. Realizar una venta \n2. Ver la lista de productos \n3. Cambiar de cuenta \n4. Salir""")
            opcion = int(input("\nIngrese una opcion -> "))
            if opcion == 1:
                venderProducto()
            elif opcion == 2:
                verProductos()
            elif opcion == 3:
                print("\n*****************************Pantalla Activa*****************************")
                print("\nA regresado al menu anterior")
                break
            elif opcion == 4:
                print("\n*****************************Pantalla Desactivada*****************************")
                print("\nA cerrado el programa, pase feliz tarde.\n")
                sys.exit()
            else:
                print("Opcion no valida")
    else:
        print("Usuario no encontrado")
